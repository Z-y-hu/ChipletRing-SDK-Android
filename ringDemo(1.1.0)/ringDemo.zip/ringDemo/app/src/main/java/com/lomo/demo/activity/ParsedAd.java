package com.lomo.demo.activity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ParsedAd {
    public byte flags;

    public List<UUID> uuids = new ArrayList<>();

    public String localName;
    public String diyInfo;
    public short manufacturer;
}
