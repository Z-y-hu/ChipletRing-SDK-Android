package com.lomo.demo.adapter;

/**
 * 点击时间
 *
 * @author Sai
 * @date 15/8/9
 */
public interface OnItemClickListener {
    public void onItemClick(Object o, int position);
}
